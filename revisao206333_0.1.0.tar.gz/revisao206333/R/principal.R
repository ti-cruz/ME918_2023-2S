# Passo 1
#library(yaml)
#config <- read_yaml("config.yaml")

# Passo 2
#devtools::install_local("revisao206333_0.1.0.tar.gz")
#library(revisao206333)

# Passo 3
# Dado que o nosso arquivo tar.gz já está na pasta do projeto

#Graf_den_hist(iris,
#              config$variavel_iris,
#              config$tipo_grafico)
